--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: censo; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE censo (
    codigo integer NOT NULL,
    nome character varying(50) NOT NULL,
    total integer NOT NULL,
    urbana numeric(6,2),
    rural numeric(6,2),
    homem numeric(6,2),
    mulher numeric(6,2),
    razao numeric(6,2)
);


ALTER TABLE public.censo OWNER TO postgres;

--
-- Name: TABLE censo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE censo IS 'População residente, total e respectiva distribuição percentual, por situação do domicílio e sexo, e razão de sexo, segundo os municípios - Pará - 2010';


--
-- Name: COLUMN censo.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.codigo IS 'Código do município';


--
-- Name: COLUMN censo.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.nome IS 'Nome do município';


--
-- Name: COLUMN censo.total; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.total IS 'População residente - Total';


--
-- Name: COLUMN censo.urbana; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.urbana IS 'Distribição percentual - Urbana';


--
-- Name: COLUMN censo.rural; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.rural IS 'Distribição percentual - Rural';


--
-- Name: COLUMN censo.homem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.homem IS 'Distribição percentual - Homem';


--
-- Name: COLUMN censo.mulher; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.mulher IS 'Distribição percentual - Mulher';


--
-- Name: COLUMN censo.razao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN censo.razao IS 'Razão de sexo (%)';


--
-- Data for Name: censo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO censo VALUES (1500107, 'Abaetetuba', 141100, 58.80, 41.20, 50.80, 49.20, 103.10);
INSERT INTO censo VALUES (1500131, 'Abel Figueiredo', 6780, 89.00, 11.00, 52.10, 47.90, 108.80);
INSERT INTO censo VALUES (1500206, 'Acará', 53569, 23.60, 76.40, 52.50, 47.50, 110.40);
INSERT INTO censo VALUES (1500305, 'Afuá', 35042, 27.10, 73.00, 52.70, 47.30, 111.20);
INSERT INTO censo VALUES (1500347, 'Água Azul do Norte', 25057, 19.50, 80.50, 54.40, 45.70, 119.10);
INSERT INTO censo VALUES (1500404, 'Alenquer', 52626, 52.70, 47.30, 51.40, 48.60, 105.60);
INSERT INTO censo VALUES (1500503, 'Almeirim', 33614, 59.40, 40.60, 52.00, 48.00, 108.20);
INSERT INTO censo VALUES (1500602, 'Altamira', 99075, 84.90, 15.10, 50.30, 49.70, 101.10);
INSERT INTO censo VALUES (1500701, 'Anajás', 24759, 38.40, 61.70, 52.30, 47.70, 109.80);
INSERT INTO censo VALUES (1500800, 'Ananindeua', 471980, 99.80, 0.30, 48.00, 52.00, 92.40);
INSERT INTO censo VALUES (1500859, 'Anapu', 20543, 47.90, 52.10, 53.50, 46.50, 115.10);
INSERT INTO censo VALUES (1500909, 'Augusto Corrêa', 40497, 45.00, 55.00, 51.80, 48.20, 107.60);
INSERT INTO censo VALUES (1500958, 'Aurora do Pará', 26546, 30.80, 69.20, 51.30, 48.70, 105.40);
INSERT INTO censo VALUES (1501006, 'Aveiro', 15849, 20.10, 79.90, 52.80, 47.20, 111.80);
INSERT INTO censo VALUES (1501105, 'Bagre', 23864, 44.70, 55.30, 50.90, 49.20, 103.50);
INSERT INTO censo VALUES (1501204, 'Baião', 36882, 50.30, 49.70, 52.70, 47.30, 111.50);
INSERT INTO censo VALUES (1501253, 'Bannach', 3431, 37.40, 62.60, 53.80, 46.20, 116.60);
INSERT INTO censo VALUES (1501303, 'Barcarena', 99859, 36.40, 63.70, 50.40, 49.60, 101.70);
INSERT INTO censo VALUES (1501402, 'Belém', 1393399, 99.10, 0.90, 47.30, 52.70, 89.70);
INSERT INTO censo VALUES (1501451, 'Belterra', 16318, 42.00, 58.00, 52.00, 48.00, 108.20);
INSERT INTO censo VALUES (1501501, 'Benevides', 51651, 56.00, 44.00, 50.00, 50.00, 99.90);
INSERT INTO censo VALUES (1501576, 'Bom Jesus do Tocantins', 15298, 53.30, 46.70, 52.60, 47.40, 111.10);
INSERT INTO censo VALUES (1501600, 'Bonito', 13630, 28.10, 71.90, 52.20, 47.80, 109.20);
INSERT INTO censo VALUES (1501709, 'Bragança', 113227, 64.10, 35.90, 50.60, 49.40, 102.40);
INSERT INTO censo VALUES (1501725, 'Brasil Novo', 15690, 44.00, 56.00, 53.00, 47.00, 112.70);
INSERT INTO censo VALUES (1501758, 'Brejo Grande do Araguaia', 7317, 58.90, 41.10, 52.40, 47.60, 110.00);
INSERT INTO censo VALUES (1501782, 'Breu Branco', 52493, 55.80, 44.20, 51.60, 48.40, 106.60);
INSERT INTO censo VALUES (1501808, 'Breves', 92860, 50.10, 49.90, 51.50, 48.50, 106.00);
INSERT INTO censo VALUES (1501907, 'Bujaru', 25695, 31.50, 68.50, 51.90, 48.10, 107.90);
INSERT INTO censo VALUES (1501956, 'Cachoeira do Piriá', 26484, 20.90, 79.10, 51.80, 48.20, 107.50);
INSERT INTO censo VALUES (1502004, 'Cachoeira do Arari', 20443, 36.00, 64.00, 51.60, 48.40, 106.50);
INSERT INTO censo VALUES (1502103, 'Cametá', 120896, 43.70, 56.30, 51.30, 48.70, 105.30);
INSERT INTO censo VALUES (1502152, 'Canaã dos Carajás', 26716, 77.60, 22.40, 50.90, 49.20, 103.50);
INSERT INTO censo VALUES (1502202, 'Capanema', 63639, 79.70, 20.30, 49.50, 50.50, 98.00);
INSERT INTO censo VALUES (1502301, 'Capitão Poço', 51893, 41.30, 58.70, 51.30, 48.70, 105.30);
INSERT INTO censo VALUES (1502400, 'Castanhal', 173149, 88.60, 11.40, 48.80, 51.20, 95.30);
INSERT INTO censo VALUES (1502509, 'Chaves', 21005, 12.00, 88.10, 53.20, 46.80, 113.80);
INSERT INTO censo VALUES (1502608, 'Colares', 11381, 32.20, 67.80, 51.70, 48.30, 106.90);
INSERT INTO censo VALUES (1502707, 'Conceição do Araguaia', 45557, 71.30, 28.70, 51.20, 48.80, 104.80);
INSERT INTO censo VALUES (1502756, 'Concórdia do Pará', 28216, 53.50, 46.50, 51.70, 48.30, 107.10);
INSERT INTO censo VALUES (1502764, 'Cumaru do Norte', 10466, 25.90, 74.10, 58.10, 41.90, 138.70);
INSERT INTO censo VALUES (1502772, 'Curionópolis', 18288, 68.50, 31.50, 52.90, 47.20, 112.10);
INSERT INTO censo VALUES (1502806, 'Curralinho', 28549, 38.30, 61.70, 52.80, 47.30, 111.60);
INSERT INTO censo VALUES (1502855, 'Curuá', 12254, 47.20, 52.80, 52.70, 47.30, 111.30);
INSERT INTO censo VALUES (1502905, 'Curuçá', 34294, 35.50, 64.50, 51.20, 48.80, 105.00);
INSERT INTO censo VALUES (1502939, 'Dom Eliseu', 51319, 63.40, 36.60, 51.90, 48.10, 107.80);
INSERT INTO censo VALUES (1502954, 'Eldorado dos Carajás', 31786, 52.20, 47.80, 52.90, 47.10, 112.30);
INSERT INTO censo VALUES (1503002, 'Faro', 8177, 74.90, 25.10, 51.90, 48.20, 107.70);
INSERT INTO censo VALUES (1503044, 'Floresta do Araguaia', 17768, 49.00, 51.00, 53.80, 46.30, 116.20);
INSERT INTO censo VALUES (1503077, 'Garrafão do Norte', 25034, 34.40, 65.60, 52.40, 47.60, 109.90);
INSERT INTO censo VALUES (1503093, 'Goianésia do Pará', 30436, 69.30, 30.70, 51.80, 48.30, 107.30);
INSERT INTO censo VALUES (1503101, 'Gurupá', 29062, 33.00, 67.00, 53.00, 47.00, 112.70);
INSERT INTO censo VALUES (1503200, 'Igarapé-Açu', 35887, 59.10, 40.90, 50.50, 49.50, 101.90);
INSERT INTO censo VALUES (1503309, 'Igarapé-Miri', 58077, 45.10, 54.90, 51.10, 48.90, 104.50);
INSERT INTO censo VALUES (1503408, 'Inhangapi', 10037, 27.60, 72.40, 51.50, 48.50, 106.20);
INSERT INTO censo VALUES (1503457, 'Ipixuna do Pará', 51309, 23.80, 76.20, 52.40, 47.60, 110.30);
INSERT INTO censo VALUES (1503507, 'Irituia', 31364, 20.80, 79.20, 51.90, 48.20, 107.70);
INSERT INTO censo VALUES (1503606, 'Itaituba', 97493, 72.50, 27.50, 51.00, 49.00, 103.90);
INSERT INTO censo VALUES (1503705, 'Itupiranga', 51220, 40.00, 60.00, 52.80, 47.20, 111.70);
INSERT INTO censo VALUES (1503754, 'Jacareacanga', 14103, 35.00, 65.00, 57.00, 43.00, 132.50);
INSERT INTO censo VALUES (1503804, 'Jacundá', 51360, 89.00, 11.10, 50.20, 49.80, 100.70);
INSERT INTO censo VALUES (1503903, 'Juruti', 47086, 33.70, 66.30, 52.20, 47.80, 109.20);
INSERT INTO censo VALUES (1504000, 'Limoeiro do Ajuru', 25021, 24.80, 75.20, 52.40, 47.60, 110.20);
INSERT INTO censo VALUES (1504059, 'Mãe do Rio', 27904, 82.60, 17.40, 49.20, 50.80, 97.00);
INSERT INTO censo VALUES (1504109, 'Magalhães Barata', 8115, 46.80, 53.20, 52.50, 47.50, 110.40);
INSERT INTO censo VALUES (1504208, 'Marabá', 233669, 79.70, 20.30, 50.60, 49.40, 102.30);
INSERT INTO censo VALUES (1504307, 'Maracanã', 28376, 41.10, 58.90, 51.80, 48.20, 107.50);
INSERT INTO censo VALUES (1504406, 'Marapanim', 26605, 44.00, 56.00, 52.20, 47.80, 109.20);
INSERT INTO censo VALUES (1504422, 'Marituba', 108246, 99.00, 1.00, 49.80, 50.20, 99.10);
INSERT INTO censo VALUES (1504455, 'Medicilândia', 27328, 35.00, 65.00, 54.50, 45.50, 119.70);
INSERT INTO censo VALUES (1504505, 'Melgaço', 24808, 22.20, 77.80, 53.30, 46.70, 114.20);
INSERT INTO censo VALUES (1504604, 'Mocajuba', 26731, 68.40, 31.60, 51.40, 48.60, 105.90);
INSERT INTO censo VALUES (1504703, 'Moju', 70018, 35.90, 64.10, 52.40, 47.60, 110.00);
INSERT INTO censo VALUES (1504802, 'Monte Alegre', 55462, 44.30, 55.70, 51.40, 48.60, 105.80);
INSERT INTO censo VALUES (1504901, 'Muaná', 34204, 42.50, 57.60, 52.40, 47.70, 109.90);
INSERT INTO censo VALUES (1504950, 'Nova Esperança do Piriá', 20158, 39.50, 60.50, 52.80, 47.20, 111.90);
INSERT INTO censo VALUES (1504976, 'Nova Ipixuna', 14645, 52.80, 47.20, 52.80, 47.20, 111.80);
INSERT INTO censo VALUES (1505007, 'Nova Timboteua', 13670, 40.40, 59.60, 51.80, 48.20, 107.50);
INSERT INTO censo VALUES (1505031, 'Novo Progresso', 25124, 70.50, 29.50, 53.50, 46.50, 114.90);
INSERT INTO censo VALUES (1505064, 'Novo Repartimento', 62050, 45.00, 55.00, 52.80, 47.20, 111.80);
INSERT INTO censo VALUES (1505106, 'Óbidos', 49333, 51.60, 48.40, 51.80, 48.20, 107.60);
INSERT INTO censo VALUES (1505205, 'Oeiras do Pará', 28595, 40.00, 60.00, 52.50, 47.50, 110.60);
INSERT INTO censo VALUES (1505304, 'Oriximiná', 62794, 63.90, 36.10, 50.60, 49.40, 102.30);
INSERT INTO censo VALUES (1505403, 'Ourém', 16311, 45.60, 54.40, 51.80, 48.20, 107.30);
INSERT INTO censo VALUES (1505437, 'Ourilândia do Norte', 27359, 72.80, 27.20, 52.20, 47.80, 109.00);
INSERT INTO censo VALUES (1505486, 'Pacajá', 39979, 34.40, 65.60, 54.00, 46.00, 117.50);
INSERT INTO censo VALUES (1505494, 'Palestina do Pará', 7475, 60.80, 39.20, 51.90, 48.10, 107.90);
INSERT INTO censo VALUES (1505502, 'Paragominas', 97819, 78.20, 21.80, 50.40, 49.60, 101.50);
INSERT INTO censo VALUES (1505536, 'Parauapebas', 153908, 90.10, 9.90, 50.60, 49.40, 102.50);
INSERT INTO censo VALUES (1505551, 'Pau D''Arco', 6033, 60.40, 39.70, 52.70, 47.30, 111.30);
INSERT INTO censo VALUES (1505601, 'Peixe-Boi', 7854, 53.10, 46.90, 51.40, 48.60, 105.90);
INSERT INTO censo VALUES (1505635, 'Piçarra', 12697, 28.20, 71.80, 53.40, 46.60, 114.50);
INSERT INTO censo VALUES (1505650, 'Placas', 23934, 20.30, 79.70, 52.50, 47.50, 110.60);
INSERT INTO censo VALUES (1505700, 'Ponta de Pedras', 25999, 47.80, 52.20, 51.50, 48.50, 106.00);
INSERT INTO censo VALUES (1505809, 'Portel', 52172, 47.60, 52.40, 51.40, 48.60, 105.80);
INSERT INTO censo VALUES (1505908, 'Porto de Moz', 33956, 43.00, 57.10, 51.90, 48.10, 107.80);
INSERT INTO censo VALUES (1506005, 'Prainha', 29349, 30.50, 69.50, 52.90, 47.10, 112.20);
INSERT INTO censo VALUES (1506104, 'Primavera', 10268, 62.20, 37.80, 51.60, 48.40, 106.70);
INSERT INTO censo VALUES (1506112, 'Quatipuru', 12411, 42.80, 57.20, 52.10, 47.90, 108.60);
INSERT INTO censo VALUES (1506138, 'Redenção', 75556, 92.70, 7.30, 50.30, 49.70, 101.20);
INSERT INTO censo VALUES (1506161, 'Rio Maria', 17697, 76.40, 23.70, 51.80, 48.20, 107.30);
INSERT INTO censo VALUES (1506187, 'Rondon do Pará', 46964, 73.90, 26.10, 51.70, 48.30, 107.00);
INSERT INTO censo VALUES (1506195, 'Rurópolis', 40087, 38.10, 61.90, 52.10, 47.90, 108.60);
INSERT INTO censo VALUES (1506203, 'Salinópolis', 37421, 89.20, 10.80, 51.00, 49.00, 104.20);
INSERT INTO censo VALUES (1506302, 'Salvaterra', 20183, 62.80, 37.20, 51.00, 49.00, 104.00);
INSERT INTO censo VALUES (1506351, 'Santa Bárbara do Pará', 17141, 31.80, 68.20, 51.10, 48.90, 104.40);
INSERT INTO censo VALUES (1506401, 'Santa Cruz do Arari', 8155, 49.00, 51.00, 50.80, 49.20, 103.20);
INSERT INTO censo VALUES (1506500, 'Santa Isabel do Pará', 59466, 72.30, 27.70, 52.40, 47.60, 110.00);
INSERT INTO censo VALUES (1506559, 'Santa Luzia do Pará', 19424, 44.80, 55.30, 50.90, 49.10, 103.60);
INSERT INTO censo VALUES (1506583, 'Santa Maria das Barreiras', 17206, 37.00, 63.10, 55.20, 44.80, 123.20);
INSERT INTO censo VALUES (1506609, 'Santa Maria do Pará', 23026, 57.90, 42.10, 49.90, 50.10, 99.60);
INSERT INTO censo VALUES (1506708, 'Santana do Araguaia', 56153, 52.80, 47.20, 53.10, 47.00, 113.00);
INSERT INTO censo VALUES (1506807, 'Santarém', 294580, 73.30, 26.80, 49.40, 50.60, 97.60);
INSERT INTO censo VALUES (1506906, 'Santarém Novo', 6141, 29.50, 70.50, 52.30, 47.70, 109.60);
INSERT INTO censo VALUES (1507003, 'Santo Antônio do Tauá', 26674, 55.80, 44.30, 50.40, 49.60, 101.50);
INSERT INTO censo VALUES (1507102, 'São Caetano de Odivelas', 16891, 41.20, 58.80, 52.10, 47.90, 108.90);
INSERT INTO censo VALUES (1507151, 'São Domingos do Araguaia', 23130, 66.00, 34.10, 51.50, 48.60, 106.00);
INSERT INTO censo VALUES (1507201, 'São Domingos do Capim', 29846, 22.10, 77.90, 52.70, 47.30, 111.60);
INSERT INTO censo VALUES (1507300, 'São Félix do Xingu', 91340, 49.40, 50.60, 53.30, 46.70, 114.20);
INSERT INTO censo VALUES (1507409, 'São Francisco do Pará', 15060, 34.00, 66.10, 51.60, 48.40, 106.70);
INSERT INTO censo VALUES (1507458, 'São Geraldo do Araguaia', 25587, 53.10, 46.90, 51.20, 48.80, 104.80);
INSERT INTO censo VALUES (1507466, 'São João da Ponta', 5265, 19.60, 80.40, 52.00, 48.00, 108.30);
INSERT INTO censo VALUES (1507474, 'São João de Pirabas', 20647, 50.80, 49.20, 52.10, 47.90, 108.80);
INSERT INTO censo VALUES (1507508, 'São João do Araguaia', 13155, 19.70, 80.30, 54.30, 45.70, 119.00);
INSERT INTO censo VALUES (1507607, 'São Miguel do Guamá', 51567, 61.80, 38.20, 50.50, 49.50, 101.90);
INSERT INTO censo VALUES (1507706, 'São Sebastião da Boa Vista', 22904, 43.20, 56.80, 51.70, 48.30, 106.90);
INSERT INTO censo VALUES (1507755, 'Sapucaia', 5047, 65.90, 34.10, 53.70, 46.30, 116.00);
INSERT INTO censo VALUES (1507805, 'Senador José Porfírio', 13045, 49.60, 50.40, 53.60, 46.40, 115.60);
INSERT INTO censo VALUES (1507904, 'Soure', 23001, 91.40, 8.60, 49.90, 50.10, 99.50);
INSERT INTO censo VALUES (1507953, 'Tailândia', 79297, 74.00, 26.00, 51.70, 48.30, 107.00);
INSERT INTO censo VALUES (1507961, 'Terra Alta', 10262, 42.20, 57.80, 51.40, 48.60, 105.60);
INSERT INTO censo VALUES (1507979, 'Terra Santa', 16949, 61.00, 39.00, 51.80, 48.20, 107.40);
INSERT INTO censo VALUES (1508001, 'Tomé-Açu', 56518, 55.90, 44.20, 51.90, 48.10, 107.80);
INSERT INTO censo VALUES (1508035, 'Tracuateua', 27455, 26.40, 73.60, 52.20, 47.80, 109.20);
INSERT INTO censo VALUES (1508050, 'Trairão', 16875, 33.70, 66.40, 54.20, 45.80, 118.30);
INSERT INTO censo VALUES (1508084, 'Tucumã', 33690, 79.90, 20.10, 51.90, 48.10, 107.90);
INSERT INTO censo VALUES (1508100, 'Tucuruí', 97128, 95.20, 4.80, 49.80, 50.20, 99.30);
INSERT INTO censo VALUES (1508126, 'Ulianópolis', 43341, 65.80, 34.20, 51.20, 48.80, 105.10);
INSERT INTO censo VALUES (1508159, 'Uruará', 44789, 54.50, 45.50, 52.80, 47.20, 111.70);
INSERT INTO censo VALUES (1508209, 'Vigia', 47889, 67.60, 32.40, 51.30, 48.70, 105.20);
INSERT INTO censo VALUES (1508308, 'Viseu', 56716, 32.40, 67.60, 52.60, 47.40, 110.80);
INSERT INTO censo VALUES (1508357, 'Vitória do Xingu', 13431, 39.90, 60.10, 54.20, 45.80, 118.40);
INSERT INTO censo VALUES (1508407, 'Xinguara', 40573, 77.60, 22.40, 50.70, 49.30, 102.80);


--
-- Name: censo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY censo
    ADD CONSTRAINT censo_pkey PRIMARY KEY (codigo);


--
-- PostgreSQL database dump complete
--

